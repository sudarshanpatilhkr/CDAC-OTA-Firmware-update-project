# Hardware Wiring Guide

## ESP32 to STM32F407 Discovery Board Connections

```
                  ESP32 DevKit                 STM32F407 Discovery
                 ┌───────────┐                ┌───────────────────┐
                 │           │                │                   │
    USB ────────►│  USB/UART │                │  ST-Link USB ────►│ Debug
    (Debug)      │  (Debug)  │                │  (Programming)    │
                 │           │                │                   │
                 │  GPIO17 ──┼── TX ────────► │── PA3 (USART2_RX)│
                 │  (TX2)    │                │                   │
                 │           │                │                   │
                 │  GPIO16 ──┼── RX ◄──────── │── PA2 (USART2_TX)│
                 │  (RX2)    │                │                   │
                 │           │                │                   │
                 │  GND ─────┼── GND ──────── │── GND            │
                 │           │                │                   │
                 │  GPIO2  ──┤ WiFi LED       │  PD12 ── Green   │ Boot OK
                 │  GPIO4  ──┤ OTA LED        │  PD13 ── Orange  │ OTA Active
                 │           │                │  PD14 ── Red     │ Error
                 │           │                │  PD15 ── Blue    │ Bootloader
                 │           │                │                   │
                 │  3.3V     │                │  3V               │
                 │  5V       │                │  5V               │
                 └───────────┘                └───────────────────┘


Wire Connections (3 wires minimum):
═══════════════════════════════════

1. ESP32 GPIO17 (TX2) ──────► STM32 PA3 (USART2_RX)    [Green wire]
2. ESP32 GPIO16 (RX2) ◄────── STM32 PA2 (USART2_TX)    [Yellow wire]
3. ESP32 GND ──────────────── STM32 GND                  [Black wire]

⚠️  IMPORTANT:
   - TX connects to RX (crossover)
   - Both must share common ground
   - Both operate at 3.3V logic levels
   - Do NOT connect 5V between boards
```

## LED Status Indicators

### STM32F407 Discovery Board LEDs (Port D)

| LED | Pin | Color | Bootloader State | Application State |
|-----|-----|-------|-----------------|-------------------|
| PD12 | Green | Boot OK / Running | Heartbeat blink (1Hz) |
| PD13 | Orange | Verifying update | OTA transfer active |
| PD14 | Red | Verification failed / Rollback | Error state |
| PD15 | Blue | Bootloader active | UART data activity |

### ESP32 LEDs

| GPIO | Purpose | State |
|------|---------|-------|
| GPIO2 (built-in) | WiFi status | Blinking=connecting, Solid=connected |
| GPIO4 (external) | OTA status | ON=download in progress |

## UART Configuration

| Parameter | Value |
|-----------|-------|
| Baud Rate | 115200 |
| Data Bits | 8 |
| Parity | None |
| Stop Bits | 1 |
| Flow Control | Software (ACK/NACK) |
| Format | 8N1 |

## Power Supply Options

Option 1: Both boards powered via their own USB cables
Option 2: ESP32 powered from STM32 5V pin (single USB)

## Debugging

- STM32: Use built-in ST-Link (SWD) via CubeIDE debugger
- ESP32: Use USB Serial Monitor at 115200 baud
- UART sniffing: Connect logic analyzer to PA2/PA3 lines
