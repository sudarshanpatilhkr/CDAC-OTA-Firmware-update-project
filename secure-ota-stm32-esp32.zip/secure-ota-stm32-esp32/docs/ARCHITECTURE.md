# System Architecture

## Secure OTA Firmware Update System
### CDAC ACTS PG-Diploma in DESD

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLOUD / SERVER                           │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  Python Flask OTA Server                                  │  │
│  │  ┌──────────┐  ┌──────────────┐  ┌──────────────────┐   │  │
│  │  │ Firmware  │  │ Delta Patch  │  │ SHA-256 Hash     │   │  │
│  │  │ Storage   │  │ Generator    │  │ Computation      │   │  │
│  │  │ (v1,v2..)│  │ (Page-based) │  │                  │   │  │
│  │  └──────────┘  └──────────────┘  └──────────────────┘   │  │
│  │                    REST API                               │  │
│  └──────────────────────┬────────────────────────────────────┘  │
│                         │ HTTP/HTTPS                             │
└─────────────────────────┼───────────────────────────────────────┘
                          │
                    WiFi / Internet
                          │
┌─────────────────────────┼───────────────────────────────────────┐
│  ESP32 WiFi Bridge      │                                       │
│  ┌──────────────────────┴────────────────────────────────────┐  │
│  │  ┌──────────┐  ┌──────────────┐  ┌──────────────────┐   │  │
│  │  │ WiFi     │  │ HTTP Client  │  │ UART Bridge      │   │  │
│  │  │ Manager  │  │ (Download)   │  │ (Chunked TX)     │   │  │
│  │  └──────────┘  └──────────────┘  └────────┬─────────┘   │  │
│  └───────────────────────────────────────────┼──────────────┘  │
│                                               │ UART 115200    │
└───────────────────────────────────────────────┼─────────────────┘
                                                │
┌───────────────────────────────────────────────┼─────────────────┐
│  STM32F407 Target MCU                         │                 │
│  ┌────────────────────────────────────────────┴──────────────┐  │
│  │                                                           │  │
│  │  ┌─────────────────┐                                     │  │
│  │  │   BOOTLOADER    │  0x08000000 - 0x0800FFFF (64KB)    │  │
│  │  │  - Boot logic   │                                     │  │
│  │  │  - SHA-256 verify│                                    │  │
│  │  │  - Bank switch  │                                     │  │
│  │  │  - VTOR relocate│                                     │  │
│  │  └────────┬────────┘                                     │  │
│  │           │ Jump                                          │  │
│  │  ┌────────▼────────┐  ┌────────────────┐                │  │
│  │  │   BANK A (App)  │  │   BANK B (App) │                │  │
│  │  │  0x08010000     │  │  0x08080000    │                │  │
│  │  │  Active/Inactive│◄─►│  Active/Inactive│               │  │
│  │  │  448KB          │  │  384KB         │                │  │
│  │  └─────────────────┘  └────────────────┘                │  │
│  │                                                           │  │
│  │  ┌─────────────────┐                                     │  │
│  │  │   METADATA      │  0x080E0000 (128KB)                │  │
│  │  │  - Active bank  │                                     │  │
│  │  │  - Update flags │                                     │  │
│  │  │  - SHA-256 hashes│                                    │  │
│  │  │  - Versions     │                                     │  │
│  │  └─────────────────┘                                     │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow

### Normal Boot Sequence
1. Power ON → CPU starts at 0x08000000 (Bootloader)
2. Bootloader reads metadata from 0x080E0000
3. Checks update flags and boot failure count
4. Sets VTOR to active bank address
5. Jumps to active bank's Reset_Handler
6. Application clears boot failure count
7. Application runs normally with heartbeat LED

### OTA Update Sequence
1. ESP32 polls server for new version
2. Server generates delta patch (changed pages + SHA-256)
3. ESP32 downloads patch via HTTP
4. ESP32 sends to STM32 via UART (chunked with ACK/NACK)
5. STM32 writes to inactive bank
6. STM32 verifies SHA-256
7. STM32 sets UPDATE_PENDING flag
8. System resets
9. Bootloader verifies new firmware
10. Bootloader switches active bank
11. New firmware runs

### Rollback Sequence
1. New firmware fails to boot (crash/hang)
2. Watchdog triggers reset
3. Bootloader increments boot_fail_count
4. After 3 failures: switch back to old bank
5. Old firmware boots successfully

## Security Layers

| Layer | Mechanism | Threat Mitigated |
|-------|-----------|-----------------|
| Transport | HTTPS/TLS | Eavesdropping, MITM |
| Integrity | SHA-256 | Corruption, Tampering |
| Availability | Dual-Bank | Bricking, Failed updates |
| Recovery | Rollback | Buggy firmware |
| Future | ECDSA Signatures | Firmware authenticity |

## DESD Curriculum Coverage

### 1. Microcontroller Programming
- STM32F407 HAL driver usage
- Flash memory programming (erase/write/read)
- UART peripheral configuration
- GPIO for LED status indicators
- Interrupt handling (UART Rx)
- Vector table relocation (VTOR)
- Linker script customization

### 2. Data Structures & Algorithms
- SHA-256 cryptographic hash (FIPS 180-4)
- Binary comparison for delta patches
- Circular buffer for UART reception
- State machine for OTA protocol
- Chunked transfer with checksums
- CRC-32 for metadata integrity

### 3. Embedded Operating Systems
- Bootloader design and implementation
- Memory partitioning (dual-bank)
- Boot sequence management
- Persistent flag management
- Watchdog integration concepts
- FreeRTOS task concepts

### 4. IoT Connectivity
- ESP32 WiFi connectivity (802.11)
- HTTP client-server architecture
- REST API design
- UART inter-processor communication
- Chunked transfer protocol
- HTTPS/TLS security
